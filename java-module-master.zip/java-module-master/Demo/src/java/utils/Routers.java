/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

/**
 *
 * @author heaty566
 */
public class Routers {

	public static String Login = "LoginController";
	public static String LoginP = "/WEB-INF/login.jsp";
	public static String List = "List";
}
